export const convertDate = (date: Date) => {

    return new Date(date).toLocaleString('en-US')
}